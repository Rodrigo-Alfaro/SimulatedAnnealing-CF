Used instances of the paper.

Each number represents a cell, which is assumed as the square (not necessity, but at least rectangular)

0: empty environment
1: obstacle
2: start point
3: end point